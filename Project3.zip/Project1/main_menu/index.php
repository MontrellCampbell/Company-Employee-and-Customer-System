<?php include '../view/header.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Customer Display</title>
    <link rel="stylesheet" type="text/css" href="../view/main.css">
</head>
<body>
<main>
    <nav>
        
    <h2>Main Menu</h2>
    <ul>
        <li><a href="../login_manager/admin_login.php">Administrators</a></li>
        <li><a href="../login_manager/technician_login.php">Technicians</a></li>
        <li><a href="../login_manager/customer_login.php">Customers</a></li>
    </ul>
    
    </nav>
</section>
</body>
</main>
<?php include '../view/footer.php'; ?>